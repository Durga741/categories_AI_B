require("dotenv").config();
const express = require("express");
const { Pool } = require("pg");
const multer = require("multer");
const xlsx = require("xlsx");
const cors = require("cors");
const path = require("path");

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// PostgreSQL Connection
const pool = new Pool({
  user: process.env.PG_USER,
  host: process.env.PG_HOST,
  database: process.env.PG_DB,
  password: process.env.PGPASSWORD,
  port: 5432, // Default PostgreSQL port
});

// Route: Add a Single Category
app.post("/api/categories", async (req, res) => {
  const { uid, retail_store_type, store_types, description } = req.body;

  if (!uid || !retail_store_type || !store_types || !description) {
    return res.status(400).json({ success: false, message: "All fields are required" });
  }

  try {
    const query = `
      INSERT INTO visys.t_master_category_list (uid, retail_store_type, store_types, description)
      VALUES ($1, $2, $3, $4) RETURNING *;
    `;

    const result = await pool.query(query, [uid, retail_store_type, store_types, description]);
    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (error) {
    console.error("Error inserting data:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// Multer Configuration for File Uploads
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Route: Upload Excel File and Bulk Insert
app.post("/api/categories/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: "No file uploaded" });
    }

    const workbook = xlsx.read(req.file.buffer, { type: "buffer" });
    const sheetName = workbook.SheetNames[0];
    const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);

    if (sheetData.length === 0) {
      return res.status(400).json({ success: false, message: "Empty Excel file" });
    }

    const insertQuery = `
      INSERT INTO visys.t_master_category_list (uid, retail_store_type, store_types, description)
      VALUES ($1, $2, $3, $4);
    `;

    for (const row of sheetData) {
      const { uid, retail_store_type, store_types, description } = row;

      // Validate required fields
      if (!uid || !retail_store_type || !store_types || !description) {
        continue; // Skip invalid rows
      }

      await pool.query(insertQuery, [uid, retail_store_type, store_types, description]);
    }

    res.status(200).json({ success: true, message: "Excel data uploaded successfully" });
  } catch (error) {
    console.error("Error uploading Excel file:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});


// Retrieve all categories
app.get("/api/categories", async (req, res) => {
    try {
      const result = await pool.query("SELECT * FROM visys.t_master_category_list");
      res.json(result.rows);
    } catch (error) {
      console.error("Error retrieving categories:", error);
      res.status(500).json({ success: false, message: "Failed to retrieve categories" });
    }
  });
  
  // Update a category by UID
  app.put("/api/categories/:uid", async (req, res) => {
    const { uid } = req.params;
    const { retail_store_type, store_types, description } = req.body;
  
    try {
      const query = `
        UPDATE visys.t_master_category_list
        SET retail_store_type = $1, store_types = $2, description = $3
        WHERE uid = $4
      `;
      const values = [retail_store_type, store_types, description, uid];
  
      const result = await pool.query(query, values);
  
      if (result.rowCount > 0) {
        res.json({ success: true, message: "Category updated successfully" });
      } else {
        res.status(404).json({ success: false, message: "Category not found" });
      }
    } catch (error) {
      console.error("Error updating category:", error);
      res.status(500).json({ success: false, message: "Failed to update category" });
    }
  });
  
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});